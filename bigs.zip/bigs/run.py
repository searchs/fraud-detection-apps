from application import app, views, models

app.run(port=5001)