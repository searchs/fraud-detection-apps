from flask import Blueprint, jsonify

users = Blueprint('users', __name__)


@users.route('/')
def index():
    return "<h2 style='text-align: center;'>Users Pad</h2>"


@users.route('/me')
def me():
    return jsonify({'data': 'mine'}), 200
