
import os
import sys
import subprocess
from datetime import datetime, timedelta
import logging


class IASPipeline(object):
    
    def __init__(self, run_date=None):
        self.set_run_date(run_date)
        self.ias_server = 'cxportal.integralads.com'
        self.ias_file_path = '/outbound'
        self.set_secrets()
        self.set_process_date()
        logging.info("IAS Pipeline now setup and ready to ingest")
        
        
    def set_process_date(self):
        """Returns the processing date as a dictionary
        """
        self.year  = self.run_date[:4]
        self.month = self.run_date[4:6]
        self.day = self.run_date[6:8]
    

    def set_secrets(self):
        self.ias_username = os.getenv('ias_user')
        self.ias_password = os.getenv('ias_pass')
        
    def set_run_date(self, run_date):
        if run_date is None:
            self.run_date = datetime.strftime(datetime.now() - timedelta(1), '%Y%m%d')
        else:
            self.run_date = run_date



ias = IASPipeline("20180907")
# ias = IASPipeline()
print(ias.run_date)    

