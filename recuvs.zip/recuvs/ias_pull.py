#!/usr/bin/env python

from __future__ import absolute_import, print_function

__author__ = 'Olatunji Ajibode (Ola)'

"""
 Programmatic  Utility downloads log files from IAS (Expedia partners) and then uploads to 
corresponding S3 location based on date in the format: YYYY/MM/DD
"""

import os
import sys
import subprocess
from datetime import datetime, timedelta

from subprocess import call, check_call

import pip
import traceback
import logging

try:
    import argparse
except ImportError:
    import pip
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'argparse'])

current_date = datetime.strftime(datetime.now() - timedelta(1), '%Y%m%d')

argp = argparse.ArgumentParser(description='Programmatic Utility: Downloads IAS logs for date supplied or else yesterday')
argp.add_argument('-d','--date', default=current_date, required=False, help='target file date in the format: YYYYMMDD e.g. 20180622')
args= argp.parse_args()

params = vars(args)

process_date = params["date"]

# today = datetime.strftime(datetime.now() - timedelta(1), '%Y%m%d')
today = datetime.strftime(datetime.now(),'%Y%m%d')
if today == process_date:
    process_date = current_date

print(process_date)

def get_date_details(pdate):
    """Accepts a processing date and 
    returns a diction with year, month and day
    as keys"""

    date_details = {}
    date_details['year'] = pdate[:4]
    date_details['month'] = pdate[4:6]
    date_details['day'] = pdate[6:8]
    return date_details

# IAS  SECTION
ias_username = os.getenv('ias_user')
ias_password = os.getenv('ias_pass')

ias_server = 'cxportal.integralads.com'
ias_file_path = '/outbound'

d =  get_date_details(process_date)

print(d)

process_year = d['year']
process_month = d['month']
process_day = d['day']

try:
    import pysftp
except ImportError:
    import pip
    # subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pysftp==0.2.8'])
    pip.main(['install', '--user', 'pysftp==0.2.8'])

log_files =[]
md5_hash = []

target_file_log = '928885_{0}_00.dat.gz'.format(process_date)
target_file_md5 = '928885_{0}_00.dat.gz.md5'.format(process_date)

try:
    exit
    with pysftp.Connection(ias_server,username=ias_username,
    password=ias_password ) as sftp:
        sftp.chdir("/outbound")
        print("changed to OUTBOUND directory")
        print(sftp.getcwd())
        assert sftp.getcwd() == '/outbound'
        file_list = list(sftp.listdir())
        print(file_list)

        # Check if file for date is absent 
        if file_list.__contains__(target_file_log):
            print("Target file {0} on server".format(target_file_log))
        else:
            print("No such file on server.")
            raise IOError("ALERT: {0} is not on this server currently.  Check Time: {1}".format(target_file_log, datetime.now()))

        sftp.get(target_file_log, preserve_mtime=True)
        sftp.get(target_file_md5,preserve_mtime=True)

        for report in file_list:
            if '.md5' in report:
                md5_hash.append(report)
            else:
                log_files.append(report)    
            # print(report)
        print(log_files)   
        print(md5_hash)

        print("============= LOG FILES  DETAILS ==========")

        for item in log_files:
            statinfo = os.stat(item)
            print(item, statinfo.st_size)
        
        print("============= MD5 FILES DETAILS ==========")
        for item in md5_hash:
            statinfo = os.stat(item)
            print(item, statinfo.st_size)


        print("Download now complete.....Upload to S3 bucket about to start")
except Exception as exc:
    print(exc) #move to logging

try:
    import boto
except ImportError:
    import pip
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'boto'])
    # pip.main(['install', '--user', 'boto'])

from boto.s3.key import Key
from boto.s3.connection import S3Connection

try:
    boto.connect_s3(profile_name='groimdaily')
    ias = boto.connect_s3
    ias = boto.connect_s3(profile_name='groimdaily')
    bucks = ias.get_bucket('gro-programmatic-automation-report')
    uploads = Key(bucks)
    uploads.key = '/reports/ias/{0}/{1}/{2}/{3}'.format(process_year, process_month,process_day, target_file_log)
    uploads.set_contents_from_filename('{0}'.format(target_file_log))

    uploads.key = '/reports/ias/{0}/{1}/{2}/{3}'.format(process_year, process_month,process_day, target_file_md5)
    uploads.set_contents_from_filename('{0}'.format(target_file_md5))
except Exception as e:
    print(e.message)
    sys.exit(1)

print("IAS File now in S3")
# Cleanup file only if it exists
def cleanup_files(filename):
    '''Remove downloaded file to keep the server light'''
    if os.path.isfile(filename):
        os.remove(filename)
        print("{0} removed from local".format(filename))
    else:
	    return "No {0} file on server.".format(filename)


# Test file remove step
assert cleanup_files("calculus.txt") == "No calculus.txt file on server."

cleanup_files(target_file_log)
cleanup_files(target_file_md5)

print("IAS file transfer process is complete")
