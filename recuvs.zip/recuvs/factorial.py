# n = n * (n-1) * (n-2)...2 *1

def factorial(n):
    # deal with base case
    if n == 0:
        return 0
    
    if n == 1:
        return 1 
    # reduction step
    else:
        return n * factorial(n-1)
    
    
for k in list(range(1,11)):
    print("="*59)
    print(k)
    print(factorial(k))
    print("\n")
    
