# Please complete the TODO items below

from pyspark.sql import SparkSession

import pyspark.sql.functions as psf
from pyspark.sql.functions import col


def explore_data():

    # TODO build a spark session (SparkSession is already imported for you!)
    spark = SparkSession.builder.master("local").appName("Todo App").getOrCreate()

    # couple ways of setting config
    #spark.conf.set("spark.executor.memory", '8g')
    #spark.conf.set('spark.executor.cores', '3')
    #spark.conf.set('spark.cores.max', '3')
    #spark.conf.set("spark.driver.memory", '8g')

    # TODO set correct path for file_path using Pathlib
    # TODO use a correct operator to load a csv file (cities.csv in your resources folder)

    file_path = "./resources/lesson1/csv/cities.csv"
    df = spark.read.csv(file_path, header=True)

    # view schema
    df.printSchema()

    # TODO create another dataframe, drop null columns for start_year
    df = df.where(col("start_year").isNotNull())
    # TODO select start_year and country only and get distinct values
    # TODO sort by start_year ascending
    
    ''' Another View
    distinct_df = df.na.drop(subset=['start_year']) \
        .select("start_year", "country") \
        .distinct() \
        .sort(psf.col("start_year").asc())'''

    distinct_df = df.select("start_year", "country").distinct().sort("start_year", ascending=True)

    # show distinct values
    distinct_df.show()

    # which country had the metro system the earliest?
    print(distinct_df.show(1, False))
    
    # Example: Apply UDF on column
    # df.withColumn("columnName", to_lower_udf(df["columnName"]))
    
# def sample_code():
#     from pyspark.sql import SparkSession
#     spark = SparkSession.builder \
#             .config('spark.ui.port', 3000) \
#             .master("local[2]") \
#             .appName("data exploration") \
#             .getOrCreate()

#     spark.conf.set('spark.executor.memory', '3g')
#     spark.conf.set('spark.executor.cores', '3g')

#     df = spark.read.csv('AB_NYC_2019.csv', header=True)
#     df1 = df.select('neighbourhood', 'price').distinct()
#     import pyspark.sql.functions
#     df1.rdd.getNumPartitions()
#     df1.repartition(10).agg({"price": "max"}).collect()

if __name__ == "__main__":
    explore_data()