
print("Dancing on the Ceiling")
import logging
logging.basicConfig(filename='lcm.log',level=logging.INFO)


logging.info("running the LCM app...")

def find_lcm(first_digit,second_digit):
    lcm = False
    logging.info("LCM not found yet ....")
    counter = min(first_digit,second_digit)

    while not lcm:
        # logging.info("Current LCM {}".format(counter))
        if counter % first_digit == 0 and counter % second_digit == 0:
            logging.info("LCM found: {}".format(counter))
            logging.info("The Least Common Multiple of {} and {} is {},".format(first_digit,second_digit,counter))
            break
        else:
            counter += 1
            # logging.info("Now trying this value - {} as LCM ".format(counter))
    
    logging.info("Returning LCM value: {}".format(counter))
    return counter  

assert find_lcm(3,4) == 12, "Oops! LCM should be 12!"
assert find_lcm(12,6) == 12, "Oops! LCM should be 12!"