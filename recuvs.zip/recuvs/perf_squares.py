
'''Perfect Squares'''
import logging

logging.basicConfig(filename="sqr.log", level=logging.INFO)

logging.info("Starting Perfect Squares....")
print('Enter a number to see if it\'s a perfect square.')
num = abs(int(input()))
logging.info("User entered : {}".format(num))

itr = -1

squared = False

while not squared and itr <= num ** (0.5):
    
    if itr * itr == num:
        print("Perfect Square Found! - {}".format(itr))
        logging.info("Perfect Square found: {}".format(itr))
        squared = True
        break
    else:
        itr += 1

if not squared:
    print("{} is not a Perfect Square".format(num))
else:
    print("Perfect Square!")

itr
