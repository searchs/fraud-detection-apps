import org.apache.spark.storage.StorageLevel

// implement org.apache.spark.sql.execution.streaming.state.StateStore properties

val rdd = sc.parallelize(1 to 20).map(x => (x % 4)).reduceByKey(_+_)

val df = rdd.mapValues(_ > 3)

df.persist(StorageLevel.DISK_ONLY)
df.toDebugString

df.count


val df2 = rdd.mapValues(_ > 3)

sc.setCheckpointDir("/tmp/checkpoints_example")

df2.toDebugString

df2.checkpoint

df2.count

df2.toDebugString



