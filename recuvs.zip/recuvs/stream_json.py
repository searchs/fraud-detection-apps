from pyspark.sql import SparkSession
import pyspark.sql.functions as psf
from pyspark.sql.types import *

import logging
import time

spark = SparkSession \
    .builder \
    .config("spark.ui.port", 3000) \
    .appName("Console Stream app") \
    .getOrCreate()
    
logging.info("started to listen to the host....")

jsonSchema = StructType([StructField("status", StringType(), True),
                         StructField("timestamp", TimestampType(), True)])

lines = spark.readStream \
    .option("header", "true") \
    .schema(jsonSchema) \
    .json("./json/")
    # .json("file://home/workspace/json/")
    

lines.filter(" status == 'Processed' ")

query = lines.writeStream.outputMode("append").format("console").start()
time.sleep(2)
query.awaitTermination()

'''
Using schema to ingest data
'''
countries = ['Colombia', 'US']
cities = ['Bogota', 'New York']
population = [1090099, 179001765]


schema = StructType([
    StructField('country', StringType(), True),
    StructField('city', StringType(), True),
    StructField('population', IntegerType(), True)
])

df_schema = spark.createDataFrame(list(zip(countries, cities, population)), schema=schema)

schema = StructType([
    StructField('name', StringType(), True),
    StructField('age', IntegerType(), True),
    StructField('address', StringType(), True),
    StructField('phone_number', StringType(), True)
])

